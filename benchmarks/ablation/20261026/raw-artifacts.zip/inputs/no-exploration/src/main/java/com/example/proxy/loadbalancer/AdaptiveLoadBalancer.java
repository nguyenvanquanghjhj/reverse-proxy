package com.example.proxy.loadbalancer;
import com.example.proxy.metrics.BackendMetrics;
import java.util.Comparator;
import java.util.List;
import java.util.function.ToDoubleFunction;

/** Chooses by a supplied score or bounded exploration; does not forecast or learn service time.
 * EstimatedWork predicts, and Dispatcher serializes selection with reservations and completion. */
public final class AdaptiveLoadBalancer implements LoadBalancer {
    private final int explorationInterval;
    private long dispatches;
    private String selectionReason = "NONE";
    public AdaptiveLoadBalancer(int explorationInterval) { this.explorationInterval = explorationInterval; }
    public BackendMetrics.Snapshot select(List<BackendMetrics.Snapshot> candidates) {
        return select(candidates, BackendMetrics.Snapshot::scoreMs);
    }
    public BackendMetrics.Snapshot select(List<BackendMetrics.Snapshot> candidates,
                                          ToDoubleFunction<BackendMetrics.Snapshot> completionScore) {
        if (candidates.isEmpty()) return null;
        boolean exploring = false; // ablation only
        selectionReason = exploring ? "EXPLORATION" : "MINIMUM_SCORE";
        Comparator<BackendMetrics.Snapshot> ordering = exploring
                ? Comparator.comparingLong(BackendMetrics.Snapshot::lastSelectedNanos)
                : Comparator.comparingDouble(completionScore)
                    .thenComparingLong(BackendMetrics.Snapshot::lastSelectedNanos);
        return candidates.stream().min(ordering).orElse(null);
    }
    public String getName() { return "ADAPTIVE"; }
    String selectionReason() { return selectionReason; }
}
